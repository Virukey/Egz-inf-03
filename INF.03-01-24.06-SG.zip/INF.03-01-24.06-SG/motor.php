<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Motocykle</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <img src="motor.png" alt="motocykl" id="motur">
    <header>
        <h1>Motocykle - moja pasja</h1>
    </header>
    <div class="left">
        <h2>Gdzie pojechać?</h2>
        <dl>
            <?php
            $conn = mysqli_connect("localhost", "root", "","motory");
            $kw1 = "SELECT nazwa, opis, poczatek, zdjecia.zrodlo FROM wycieczki JOIN zdjecia on wycieczki.zdjecia_id = zdjecia.id;";
            $q1 = mysqli_query($conn, $kw1);
            while($row=mysqli_fetch_array($q1)){
                echo "<dt>$row[0], rozpoczyna się w $row[2], <a href='$row[3].jpg'>zobacz zdjęcie</a></dt>
                <dd>$row[1]</dd>";          
            }
            

            ?>
        </dl>
    </div>
    <div class="right">
        <h2>Co kupić?</h2>
        <ol>
            <li>Honda CBR125R</li>
            <li>Yamaha YBR125</li>
            <li>Honda VFR800i</li>
            <li>Honda CBR1100XX</li>
            <li>BMW R1200GS LC</li>
        </ol>
    </div>
    <div class="right2">
        <h2>Statystyki</h2>
        <?php
            $kw2 = "SELECT COUNT(id) FROM `wycieczki`;";
            $q2 = mysqli_query($conn, $kw2);
            while($row=mysqli_fetch_array($q2)){
                echo "<p>Wpisanych wycieczek: $row[0]</p>";          
            }
            $conn -> close();

            ?>
        <p>Użytkowników forum: 200</p>
        <p>Przesłanych zdjęć: 1300</p>
        
    </div>
    <footer>
        <p>Stronę wykonał: 12345678900</p>
    </footer>
</body>
</html>


