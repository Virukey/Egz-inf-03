<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Poznaj Europę</title>
    <link rel="stylesheet" href="styl9.css">
</head>
<body>
    <header>
        <h1>BIURO PODRÓŻY</h1>
    </header>
    <main>
        <div class="lv">
            <h2>Promocje</h2>
            <table>
                <tr>
                    <td>Warszawa </td>
                    <td>od 600zł</td>
                </tr>
                <tr>
                    <td>Wenecja </td>
                    <td>od 1200zł</td>
                </tr>
                <tr>
                    <td>Paryż </td>
                    <td>od 1200zł</td>
                </tr>
            </table>
        </div>

        <div class="srod">
            <h2>W tym roku jedziemy do...</h2>
            <?php
                $conn = mysqli_connect("localhost", "root", "", "podroze");
                $kw1 = 'SELECT nazwaPliku, podpis FROM zdjecia ORDER BY podpis;';
                $q1 = mysqli_query($conn, $kw1);

                while($row = mysqli_fetch_array($q1)){
                    echo "<img src='" . $row["nazwaPliku"] . "' alt='" . $row["podpis"] . "'>";
                }
            ?>
        </div>

        <div class="pr">
            <h2>Kontakt</h2>
            <a href="mailto:biuro@wycieczki.pl">napisz do nas</a>
            <p>telefon: 444555666</p>
        </div>
    </main>
    <div class="dol">
        <h3>W poprzednich latach byliśmy...</h3>
        <ol>
            <?php 
                $kw2 = 'SELECT cel, dataWyjazdu FROM wycieczki WHERE dostepna = 0;';
                $q2 = mysqli_query($conn, $kw2);

                while($row = mysqli_fetch_array($q2)){
                    echo "<li>Dnia " . $row["dataWyjazdu"] . " pojechaliśmy do " . $row["cel"] . "</li>";
                }
            ?>
        </ol>
    </div>
    <footer>
        <p>Stronę wykonał:  345672563476325623756</p>
    </footer>
</body>
</html>