<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Port Lotniczy</title>
    <link rel="stylesheet" href="styl5.css">
</head>
<body>
    <header>
        <div class="baner">
            <img src="zad5.png" alt="logo lotnisko">
        </div>
        <div class="baner2">
            <h1>Przyloty</h1>
        </div>
        <div class="baner3">
            <h3>przydatne linki</h3>
            <a href="kwerendy.txt">Pobierz...</a>
        </div>
    </header>
    <main>
        <table>
            <tr>
                <th>CZAS</th>
                <th>KIERUNEK</th>
                <th>NUMER REJESTRU</th>
                <th>STATUS</th>
            </tr>
           <?php
           $conn = mysqli_connect("localhost", "root", "", "lotnisko");
           $kw1 = "SELECT czas, kierunek, nr_rejsu,status_lotu FROM przyloty ORDER BY czas ASC;";
           $q1 = mysqli_query($conn, $kw1);

           while($row = mysqli_fetch_array($q1)){
            echo "<tr>";
            echo "<td>".$row[0]."</td>";
            echo "<td>".$row[1]."</td>";
            echo "<td>".$row[2]."</td>";
            echo "<td>".$row[3]."</td>";
            echo "</tr>";
        }
           ?>
        </table>
    </main>
    <footer>
        <div class="stopka">
            <?php
           
            if(isset($_COOKIE['start'])){
                echo"<p><i>Witaj ponownie na stronie lotniska</i></p>";
            }else{
                setcookie('start','start',time()+2*60*60);
                echo"<p><b>Dzień dobry! Strona lotniska używa ciasteczek</b></p>";
            }

            mysqli_close($conn);
            ?>
        </div>
        <div class="stopka2">
            Autor: 12345678900
        </div>
    </footer>
</body>
</html>